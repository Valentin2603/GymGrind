package gymgrind;

import javafx.application.Application;

public final class Main {

    private Main() {
    }

    public static void main(String[] args) {
        Application.launch(GameApp.class, args);
    }
}
